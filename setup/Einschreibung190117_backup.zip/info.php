<html>
<body>
<?php
	phpInfo();
?>
</body>
</html>
