<!DOCTYPE html>
<html>
	<head>
		<title>Login mit Nummer</title>
		<meta name = "author" content = "Tom Reinhardt"/>
		<meta charset = "UTF-8"/>
	</head>
	<body>
		<form method = "POST">
			<span>Deine Authentifikationsnummer:</span>
			<input name = "authnum" type = "text" maxlength = "6" autofocus/>
			<input type = "submit"/>
		</form>
		<?php
			require_once("../config/db.php");
			
			if(isset($_POST['authnum']))
			{
				$dieNummer = $_POST['authnum'];
				
				$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
				
				$db_table = "nums";
				
				if(!$ref->connect_error)
				{
					$query_string = "SELECT * FROM ".$db_table." WHERE AUTHNUM = \"".$dieNummer."\"";
					$result = $ref->query($query_string);
					
					$theValueS = $result->fetch_array(MYSQLI_NUM);
					
					if(isset($theValueS[0]))
					{
						if($theValueS[0] == $dieNummer)
						{
							echo "<h1>Die Nummer wurde gefunden</h1>".PHP_EOL;
							$query_string = "DELETE FROM ".$db_table." WHERE AUTHNUM = \"".$dieNummer."\";";
							$ref->query($query_string);
						}
					}
					else
						echo "<h1>Die Nummer wurde nicht gefunden</h1>".PHP_EOL;
				}
				else
				{
					die("Die Datenbankverbindung ist fehlgeschlagen".PHP_EOL."Melde dies bitte dem Systemadministrator");
				}
				
				$ref->close();
			}
		?>
	</body>
</html>