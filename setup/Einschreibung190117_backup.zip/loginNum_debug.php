<!DOCTYPE html>
<html>
	<head>
		<title>Login mit Nummer</title>
		<meta name = "author" content = "Tom Reinhardt"/>
		<meta charset = "UTF-8"/>
	</head>
	<body>
		<form method = "POST">
			<span>Deine Authentifikationsnummer:</span>
			<input name = "authnum" type = "text" maxlength = "6" autofocus/>
			<input type = "submit"/>
		</form>
		<?php
			session_start();
			require_once("../config/db.php");
			
			if(isset($_POST['authnum']))
			{
				$dieNummer = $_POST['authnum'];
				
				$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
				
				$db_table = "nums";
				
				if(!$ref->connect_error)
				{
					if(isGiven($db_table, "AUTHNUM", $dieNummer))
					{
						$_SESSION["AUTH"] = true;
						$_SESSION["KEY"] = $dieNummer;
						echo "Gefunden";
					}
					else
						echo "nicht gefunden";
				}
				else
				{
					die("Die Datenbankverbindung ist fehlgeschlagen".PHP_EOL."Melde dies bitte dem Systemadministrator");
				}
				
				$ref->close();
			}
		?>
	</body>
</html>