<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8"/>
		<title>Register User</title>
		<link rel = "stylesheet" href = "../Styles/style.css"/>
		<style>
			body
			{
				text-align: center;
				color: #ecf0f1;
				background-color: #34495e;
				font-family: Arial;
			}
			
			#wrapper1
			{
				float: left;
				padding-left: 20%;
				text-align: right;
			}
			
			input
			{
				background-color: inherit;
				color: inherit;
				text-decoration: none;
				font-size: 20px;
			}
		</style>
	</head>
	
	<body>
		<form method = "POST">
			<div id = "wrapper1">
				<label for = "authkey">Authentifikationsnummer: </label><input name = "authkey" type = "text" maxlength = "6"/><?php if(isset($_POST['authkey'])) { if(!isGiven("nums", "AUTHNUM", $_POST['authkey'])) echo "<span class = \"Error\"><-- Es gibt diese Nummer nicht</span>"; } ?><br>
				<label for = "vname">Vorname: </label><input name = "vname" type = "text"/><?php if(isset($_POST['vname'])) { if(empty($_POST['vname'])) echo "<span class = \"Error\"><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "nname">Nachname: </label><input name = "nname" type = "text"/><?php if(isset($_POST['nname'])) { if(empty($_POST['nname'])) echo "<span class = \"Error\"><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "password">Passwort: </label><input name = "password" type = "password"/><?php if(isset($_POST['password'])) { if(empty($_POST['password'])) echo "<span class = \"Error\"><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "email">Email: </label><input name = "email" type = "e-mail"/><?php if(isset($_POST['email'])) { if(empty(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))) echo "<span class = \"Error\"><-- Dies ist keine Richtige Email-Addresse</span>"; } ?><br>
				<input type = "submit"/><br>
				
				<?php
					require_once("../config/db.php");
					
					$getTrou = TRUE;
					
					for($i = 1; $i < 5 + 1; $i++)
					{
						if(!isset($argv[$i]))
							$getTrou = FALSE;
					}
					
					if($getTrou)
					{
						$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
						if(!$ref->connect_error)
						{
							// Set Vars
							$authkey = $argv[1];
							$vname = $argv[2];
							$nname = $argv[3];
							$password = $argv[4];
							$email = $argv[5];
							$type = null;
							$alevel = null;
							$username = null;
							$changed_username = FALSE;
							
							
							// Only go ahead if the Number is given
							if(isGiven($db_table_num, "AUTHNUM", $authkey))
							{
								// Build the Username
								$query_string = "SELECT type FROM ".$db_table_num." WHERE AUTHNUM = \"".$authkey."\";";
								$result = $ref->query($query_string);// or die($db_query_error_msg);
								$type = $result->fetch_array(MYSQLI_NUM)[0];
								$result->close();
								if($type == $student_prefix)
								{
									$query_string = "SELECT alevel FROM ".$db_table_num." WHERE AUTHNUM = \"".$authkey."\";";
									$result = $ref->query($query_string); // or die($db_query_error_msg);
									$alevel = $result->fetch_array(MYSQLI_NUM)[0];
									$result->close();
									$username = $type.$alevel.$nname.$vname[0];
								}
								else
								{
									$username = $type.$nname.$vname[0];
								}
								
								// If the username is already given
								$postfix = "";
								$counter = 2;
								while(isGiven($db_table_user, "username", $username.$postfix))
								{
									$postfix = strval($counter);
									$counter++;
								}
								$username = $username.$postfix;
								
								// Insert all information in database + delete the authkey
								if($type == $student_prefix)
									$query_string = "INSERT INTO ".$db_table_user." (username, password, vname, nname, email, alevel, type) values(\"".$username."\", \"".sha1($password)."\", \"".$vname."\", \"".$nname."\", \"".$email."\", \"".$alevel."\", \"".$type."\");";
								else if($type != $student_prefix)
									$query_string = "INSERT INTO ".$db_table_user." (username, password, vname, nname, email, type) values(\"".$username."\", \"".sha1($password)."\", \"".$vname."\", \"".$nname."\", \"".$email."\", \"".$type."\");";
								
								if($ref->query($query_string)) //or die($db_query_error_msg);
								{
									$query_string = "DELETE FROM ".$db_table_num." WHERE AUTHNUM = \"".$authkey."\";";
									$ref->query($query_string); //or die($db_query_error_msg);
									$ref->close();
								
									// Give feedback to the user
									if($counter > 2)
									{
										echo "<span>Erfolgreich registriert</span>".PHP_EOL;
										switch($type)
										{
											case 'S':
												echo "<span>Da dein generierter Benutzername bereits vergeben ist".PHP_EOL."lautet deiner jetzt ".$username."</span>".PHP_EOL;
											break;
											case 'A':
											case 'T':
												echo "<span>Da ihr generierter Benutzername bereits vergeben ist".PHP_EOL."lautet ihrer jetzt ".$username."</span>".PHP_EOL;
											break;
										}
									}
									else
									{
										echo "<span>Erfolgreich registriert</span>".PHP_EOL;
										switch($type)
										{
											case 'S':
												echo "<span>Dein Benutzername lautet ".$username."</span>".PHP_EOL;
											break;
											case 'A':
											case 'T':
												echo "<span>Ihr Benutzername lautet ".$username."</span>".PHP_EOL;
											break;
										}
									}
								}
								else
									die($db_query_error_msg);
							}
							else
							{
								die("Die Nummer wurde nicht gefunden".PHP_EOL);
							}
						}
						else
							die($db_con_error_msg);
					}
				?>
			</div>
		</form>
	</body>
</html>