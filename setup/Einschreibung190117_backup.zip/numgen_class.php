<?php
	require_once("../config/db.php");
	
	// 1 --> number: howmany keys
	// 2 --> character: "T" --> Teacher, 'S' --> Student (requires year), 'A' --> Admin // configure in ../config/db.php
	// 3 --> number: alevel 2019
	// 4 --> number: time in seconds before decay after creation
	
	if(isset($argv[1]) && isset($argv[2]))
	{
		$count = intval($argv[1]);
		$specifier = strtoupper($argv[2]);
		
		if($specifier == $student_prefix && isset($argv[3]))
		{
			$year = intval($argv[3]);
		}
		else if($specifier == $student_prefix && !isset($argv[3]))
		{
			die("Usage: php ".$argv[0]." [keys] [type] [alevel] Note: type=".$student_prefix." requires year".PHP_EOL);
		}
		
		if(($specifier == $student_prefix || $specifier == $teacher_prefix || $specifier == $admin_prefix) && $count > 0)
		{
			$charset = "0123456789ABCDEF";
			$length = 6;
			$allnums = array();
			$found = true;
			
			$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
			$db_table = "nums";
			
			if(!$ref->connect_error)
			{
				for($i = 0; $i < $count; $i++)
				{
					$found = false;
					do
					{
						$newnum = "000000";
						for($p = 0; $p < $length; $p++)
						{
							$newnum[$p] = $charset[random_int(0, strlen($charset) - 1)];
						}
						
						for($p = 0; $p < count($allnums); $p++)
						{
							if($allnums[$p] == $newnum)
							{
								$found = true;
								break;
							}
						}
						
						if(isGiven($db_table, "AUTHNUM", $newnum))
							$found = true;
					}
					while($found);
					
					$allnums[] = $newnum;
				}
				
				for($o = 0; $o < count($allnums); $o++)
				{
					if($specifier == $student_prefix)
						$query_string = "INSERT INTO ".$db_table." (AUTHNUM, type, alevel) values(\"".$allnums[$o]."\", \"".$specifier."\", \"".$year."\");";
					else
						$query_string = "INSERT INTO ".$db_table." (AUTHNUM, type) values(\"".$allnums[$o]."\", \"".$specifier."\");";
					
					echo $allnums[$o].PHP_EOL;
					
					$ref->query($query_string) or die($db_query_error_msg);
				}
			}
			else
			{
				die($db_con_error_msg.PHP_EOL);
			}
		}
		else
		{
			die("Usage: php ".$argv[0]." [keys] [type] [alevel]".PHP_EOL);
		}
	}
	else
	{
		die("USAGE: php ".$argv[0]." [keys] [type] [alevel]".PHP_EOL);
	}
?>