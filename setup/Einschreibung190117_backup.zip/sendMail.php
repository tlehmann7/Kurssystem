<!DOCTYPE html>
<html>
	<head>
	
	</head>
	<body>
		<?php
			mail("wasserfrosch1234@gmail.com", "TestMail", "Thäts da message") or die("error occured");
		?>
	</body>
</html>