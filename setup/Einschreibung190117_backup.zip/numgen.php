<!DOCTYPE html>
<html>
<body>
<?php
	require_once("../config/db.php");
	
	global $db_name;
	global $db_host;
	global $db_user;
	global $db_password;
	
	if(isset($_GET['howmany']))
	{
		$count = intval($_GET['howmany']);
	}
	else if(isset($argv[1]))
		$count = intval($argv[1]);
	else
		die("Nothing defined".PHP_EOL);
	
	$charset = "0123456789ABCDEF";
	$length = 6;
	$allnums = array();
	$found = true;
	
	$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
	$db_table = "nums";
	
	if(!$ref->connect_error)
	{
		for($i = 0; $i < $count; $i++)
		{
			$found = false;
			do
			{
				$newnum = "000000";
				for($p = 0; $p < $length; $p++)
				{
					$newnum[$p] = $charset[random_int(0, strlen($charset) - 1)];
				}
				
				for($p = 0; $p < count($allnums); $p++)
				{
					if($allnums[$p] == $newnum)
					{
						$found = true;
						break;
					}
				}
			}
			while($found);
			
			$allnums[] = $newnum;
		}
		
		for($o = 0; $o < count($allnums); $o++)
		{
			$query_string = "INSERT INTO ".$db_table." values(\"".$allnums[$o]."\");";
			echo "<p>".$query_string."</p>".PHP_EOL;
			$ref->query($query_string);
		}
	}
	else
	{
		die("Connection error occured".PHP_EOL);
	}
?>
</body>
</html>