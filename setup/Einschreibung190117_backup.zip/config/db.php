<?php
	$db_host = "localhost";
	$db_user = "root";
	$db_password = "zisch27";
	$db_name = "schule";
	
	$db_table_user = "users";
	$db_table_num = "nums";
	
	$db_con_error_msg = "A database connection error occured".PHP_EOL;
	$db_query_error_msg = "A database query error occured".PHP_EOL;
	
	$student_prefix = 'S';
	$teacher_prefix = 'T';
	$admin_prefix = 'A';
	
	$pw_min_length = 4;
	
	function isGiven($db_table, $db_column, $value)
	{
		global $db_host;
		global $db_user;
		global $db_password;
		global $db_name;
		
		$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
		
		if(!$ref->connect_error)
		{
			if(is_string($value))
					$value = "\"".$value."\"";

			$query_string = "SELECT * FROM ".$db_table." WHERE ".$db_column." = ".$value.";";
			$result = $ref->query($query_string);
			if(!is_bool($result))
			{
				if(count($result->fetch_array(MYSQLI_NUM)) > 0)
				{
					return TRUE;
				}
				else
				{
					return FALSE;
				}
			}
			else
				return FALSE;
		}
	}
	
	/*function isEmail($themail)
	{
		if(count($themail) < 6)
			return FALSE;
		else
		{
			$at = FALSE;
			$tld = FALSE;
			$pre = FALSE;
			$post = FALSE;
			$atpos = 0;
			$tldpos = 0;
			for($i = 0; $i < count($themail); $i++)
			{
				if($themail[$i] == '@')
				{
					if(!$at)
					{
						$at = TRUE;
						$atpos = $i;
						if($i > 0)
							$pre = TRUE;
						else
							return FALSE;
					}
					else
						return FALSE;
				}
			}
			
			for($i = count($themail) - 1; $i >= 0; $i++)
			{
				if(!$tld && $themail[$i] == '.' && $i < count($themail) - 1)
				{
					$tld = TRUE;
					$tldpos = $i;
				}
			}
			
			if($tldpos - $atpos >= 2)
				$post = TRUE;
			
			if($pre && $at && 
		}
	}*/
?>