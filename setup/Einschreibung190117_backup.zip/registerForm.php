<!DOCTYPE html>
<html>
	<head>
		<meta charset = "UTF-8"/>
		<title>Register User</title>
		<style>
			body
			{
				text-align: center;
				color: #ecf0f1;
				background-color: #34495e;
				font-family: Arial;
			}
			
			#wrapper1
			{
				float: left;
				padding-left: 20%;
				text-align: right;
			}
			
			input
			{
				background-color: inherit;
				color: inherit;
				text-decoration: none;
				font-size: 20px;
			}
		</style>
	</head>
	
	<body>
		<form method = "POST">
			<div id = "wrapper1">
				<label for = "username">Benutzername: </label><input name = "username" type = "text"/><?php if(isset($_POST['username'])) { if(empty($_POST['username'])) echo "<span><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "password">Passwort: </label><input name = "password" type = "password"/><?php if(isset($_POST['password'])) { if(empty($_POST['password'])) echo "<span><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "vname">Vorname: </label><input name = "vname" type = "text"/><?php if(isset($_POST['vname'])) { if(empty($_POST['vname'])) echo "<span><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "nname">Nachname: </label><input name = "nname" type = "text"/><?php if(isset($_POST['nname'])) { if(empty($_POST['nname'])) echo "<span><-- Diese Information ist verbindlich</span>"; } ?><br>
				<label for = "email">Email: </label><input name = "email" type = "e-mail"/><?php if(isset($_POST['email'])) { if(empty(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))) echo "<span><-- Dies ist keine Richtige Email-Addresse</span>"; } ?><br>
				<input type = "submit"/><br>
				
				<?php
					require_once("../config/db.php");
					
					if(isset($_POST['username']))
					{
						if(isGiven("users", "username", $_POST['username']))
						{
							echo "<span>Den Benutzernamen gibt es schon</span><br>";
						}
					}
	
					if($_POST['username'] != "" && !isGiven($db_table, "username", $_POST['username']) && $_POST['password'] != "" && $_POST['vname'] != "" && $_POST['nname'] != "" && !empty(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)))
					{
						$db_table = "users";
						$ref = new mysqli($db_host, $db_user, $db_password, $db_name);
						if(!$ref->connect_error)
						{
							$query_string = "INSERT INTO ".$db_table." (username, password, vname, nname, email) values(\"".$_POST['username']."\", \"".sha1($_POST['password'])."\", \"".$_POST['vname']."\", \"".$_POST['nname']."\", \"".$_POST['email']."\");";
						
							$ref->query($query_string);
							$ref->close();
							
							echo "<span>Erfolgreich registriert</span>";
						}
						else
							die($db_con_error_msg);
					}
				?>
			</div>
		</form>
	</body>
</html>